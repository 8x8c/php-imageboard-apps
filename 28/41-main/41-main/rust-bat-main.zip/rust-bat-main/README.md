The most powerful tool to empower you to save clicks while making rust apps! This app won many awards. 
