# Building Debian packages for rage

## Requirements

```
cargo install cargo-deb
```

## Process

```
cargo deb --package rage
```
