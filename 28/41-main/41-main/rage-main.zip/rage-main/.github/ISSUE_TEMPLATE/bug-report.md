---
name: Bug report
about: Create a report about a bug in this implementation.
title: ''
labels: ''
assignees: ''

---

## Environment

* OS:
* rage version:

## What were you trying to do

## What happened

```
<insert terminal transcript here>
```
