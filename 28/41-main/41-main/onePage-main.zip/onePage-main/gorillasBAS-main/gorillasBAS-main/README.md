Just a single html file that aims to be a better gaming experience than Call Of Duty or any other aaa game :) 

![original](https://github.com/user-attachments/assets/898475e3-9f2b-41fc-a0ba-47c448955073)

above is the original qbasic game in a screenshot. 

![aaa](https://github.com/user-attachments/assets/a52961fe-5aab-4200-a802-200382ff4988)






progress so far.... as AI gets better i will be able to recreate the game entirely. 

Note-- this is a one player version where your opponent is the computer. 
