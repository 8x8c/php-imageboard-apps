
 ![Screenshot 2024-12-06 184420](https://github.com/user-attachments/assets/c05573bb-2f37-40f3-9389-966ff5941f23)



this is https://github.com/x1a7x/SIMPLE-RUST-TEXBOARD (which uses sled db) converted to use postgres. 





Don't know how to code in rust? NO PROBLEM!! 





# How to instantly learn to code in Rust !! 
notes/feed.txt is all the code. feed that file to chatgpt and you can tell it what to change.... weeeeeeeeeeeeeeeeeeeeeeeeeeeeeee :)
