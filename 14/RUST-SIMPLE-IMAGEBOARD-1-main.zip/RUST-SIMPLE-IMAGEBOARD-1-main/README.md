![Screenshot 2024-12-07 134515](https://github.com/user-attachments/assets/0dd43578-4530-406b-95d8-10e34a4ae04f)
![Screenshot 2024-12-07 130659](https://github.com/user-attachments/assets/164eef0d-4ba8-443c-ba11-b368723a2fb6)


Sick of crap imageboards on git? ME TOO! Heck, even the ones so far made in rust are hard to install, out of date and not complete. Well, enough of that nonsense!


This is set to port 8080. 

Upload all the files to the web, compile it and run it. No bs setup, no tinkering. Bam! 

This runs off the sled db, which is made in rust and for rust. NO config- just run it. 
Need an admin area? Think again. Just make a .sh script to handle any admin task you might need to do. Having a front facing admin area is just stupid. Rust IS SECURE but if you create your own security holes, that is just silly!! 

Lastly, want anything changed? Here is what you do. Copy and paste the code to EVERY file to one single text file- specify the name of each file of course. Then feed the single text file to chatgpt or similar, and tell it what to change for you. Bam! And yes- rust is hard. So you have to be reasonable. Have chat gpt make one small code change at a time or it will mess ur code up bad. It can be done tho, IF you go slow..one small change at a time and logical interaction with chatgpt and be patient!! YES you will prolly have to feed the compiler error messages back to chat gpt about 10000000 times, but hey, its rust. Get used to it :) 
