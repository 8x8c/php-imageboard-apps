

This is a special verion of https://github.com/x1a7x/RUST-SIMPLE-IMAGEBOARD-1  and its a bit deal. Why? Well take a good look at all the imageboards coded in rust currently on git. Not a single one of them has a codebase so small as this one is, and not a single one of them are as easy to install as this one is. I took the RUST-SIMPLE-IMAGEBOARD-1 and removed the askama template engine and just hard coded the html. This is amazing, and a good demo of why anyone should start wondering why php, node js, go, and even rust imageboards sometimes have hundreds of files. That is just silly. You see, one can make tiny small rust apps like this for about anything web or pc related. Its a big deal. For web apps, one can have a small codebase running a wasm app- as close to god as any web app can get! 

![2](https://github.com/user-attachments/assets/e2fa6b47-bbf5-4740-8328-6c5f80eea72d)



![Screenshot 2024-12-07 191718](https://github.com/user-attachments/assets/8c078519-7e12-4e30-924e-354d663ce66d)
