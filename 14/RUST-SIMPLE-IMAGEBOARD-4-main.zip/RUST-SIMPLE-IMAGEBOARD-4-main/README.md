![Screenshot 2024-12-07 221806](https://github.com/user-attachments/assets/f9742940-94bd-4450-b376-1b2df644fe4c)


This is RUST-SIMPLE-IMAGEBOARD-3 with more advanced image handling and display. In fact this tiny codebase and simple no config easy to install app rivals the image display of any board out there- and this can easily be modified. 

