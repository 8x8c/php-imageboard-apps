![Screenshot 2024-12-07 210932](https://github.com/user-attachments/assets/5be79fe8-e4f9-4efa-b379-dfde4aa4d683)


This is RUST-SIMPLE-IMAGEBOARD-2 with mp4 jpg gif png and webp support. No template engine, renders html pages directly. Uses sled db- very fast and nice. 
