this is https://github.com/x1a7x/articles and i converted it from the sled db to postgres. reset.sh expects the specific db with the specific id and pass to already be there. But reset.sh clears all the tables in the existing db, which is awesome for testing (starting fresh) each time you change code. notes/post.txt even has instructions to make the db with the proper password. and to run this you need to look at notes/to run .txt   


App fully works, but this is meant as a prototype, a starting point. 
