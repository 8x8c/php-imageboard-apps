This is https://github.com/x1a7x/Articles-1 with superior moderation features. Pretty dam solid!! 
