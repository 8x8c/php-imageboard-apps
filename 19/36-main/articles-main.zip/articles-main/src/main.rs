
use actix_web::{web, App, HttpServer, HttpResponse, Error};
use sled::Db;
use actix_web::web::Data;
use std::sync::Arc;
use serde::{Deserialize, Serialize};
use actix_multipart::Multipart;
use futures_util::stream::StreamExt as _;
use std::io::{Write, BufWriter};
use std::fs::{self, File};
use std::path::Path;
use sanitize_filename::sanitize;
use serde_json;
use std::fs::OpenOptions;
use chrono::Utc;

// Configuration options
const MAIN_PAGE_TITLE: &str = "All Articles";  // Variable for the main page title

// Define the optimized Article struct
#[derive(Serialize, Deserialize, Clone)]
struct Article {
    id: u64,
    title: String,
    body: String,
    media_paths: Vec<String>,
    bump_time: i64,  // Field to determine when the article was last updated/bumped
}

#[derive(Deserialize)]
struct CommentForm {
    comment: String,
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // Ensure directories exist and set permissions
    create_and_set_permissions("uploads")?;
    create_and_set_permissions("article_metadata_db")?;

    // Open Sled database
    let db = sled::open("article_metadata_db").expect("Failed to open Sled database");

    // Wrap the database in Arc and then in Data
    let db_data = Data::new(Arc::new(db));

    // Start HTTP server
    HttpServer::new(move || {
        App::new()
            .app_data(db_data.clone()) // Correctly share the database handle using Data::new()
            .route("/", web::get().to(new_article_form)) // Main page for submitting articles
            .route("/submit", web::post().to(submit_article)) // Submission route for new articles
            .route("/articles", web::get().to(list_articles)) // Route to list all articles
            .route("/articles/{id}", web::get().to(view_article)) // Route to view a specific article by ID
            .route("/articles/{id}/comment", web::post().to(submit_comment)) // Route to submit a comment
            .service(actix_files::Files::new("/static", "./static")) // Serve static files (CSS, JS, etc.)
            .service(actix_files::Files::new("/uploads", "./uploads")) // Serve uploaded files
    })
    .bind("127.0.0.1:8080")?
    .run()
    .await
}

// Function to create a directory and set permissions
fn create_and_set_permissions(dir: &str) -> std::io::Result<()> {
    if !Path::new(dir).exists() {
        fs::create_dir(dir)?;
    }
    Ok(())
}

// Utility function to log errors to "error.txt"
fn log_error(error_message: &str) {
    if let Ok(file) = OpenOptions::new().create(true).append(true).open("error.txt") {
        let mut writer = BufWriter::new(file);
        if let Err(e) = writeln!(writer, "ERROR: {}", error_message) {
            eprintln!("Failed to write to log file: {}", e);
        }
    } else {
        eprintln!("Failed to open log file for writing.");
    }
}

// Route to display the article submission form
async fn new_article_form() -> HttpResponse {
    let html = r#"
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Submit a New Article</title>
        <link rel="stylesheet" href="/static/style.css">
        <style>
            .post-form-box {
                background: #fff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                margin: 50px auto;
                max-width: 400px;
                text-align: center;
            }
            form input[type="text"], form textarea {
                width: 100%;
                padding: 10px;
                margin-top: 10px;
                margin-bottom: 15px;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
            }
            form input[type="file"] {
                margin-bottom: 15px;
            }
            form input[type="submit"] {
                background: #333;
                color: #fff;
                padding: 10px 20px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }
            form input[type="submit"]:hover {
                background: #555;
            }
        </style>
    </head>
    <body>
        <div class="post-form-box">
            <h1>Submit a New Article</h1>
            <form action="/submit" method="POST" enctype="multipart/form-data">
                <input type="text" name="title" placeholder="Title" required><br>
                <textarea name="body" rows="10" placeholder="Body" required></textarea><br>
                <input type="file" name="media" accept=".jpg,.jpeg,.png,.gif,.webp,.mp4" required><br><br>
                <label>jpg, png, gif, webp, or MP4</label><br><br>
                <input type="submit" value="Submit Article">
            </form>
        </div>
        <br>
        <a href="/articles" style="display: block; text-align: center;">View All Articles</a>
    </body>
    </html>
    "#;

    HttpResponse::Ok().content_type("text/html").body(html)
}

// Route to handle the submission of new articles, including file upload
async fn submit_article(db: web::Data<Arc<Db>>, mut payload: Multipart) -> Result<HttpResponse, Error> {
    let mut title = String::new();
    let mut body = String::new();
    let mut media_paths = Vec::new();

    create_and_set_permissions("uploads").expect("Failed to create or set permissions for uploads directory");

    while let Some(item) = payload.next().await {
        let mut field = item?;
        let content_disposition = field.content_disposition().unwrap();
        let field_name = content_disposition.get_name().unwrap();

        if field_name == "title" {
            let mut value = Vec::new();
            while let Some(chunk) = field.next().await {
                value.extend_from_slice(&chunk?);
            }
            title = String::from_utf8(value).unwrap();
        } else if field_name == "body" {
            let mut value = Vec::new();
            while let Some(chunk) = field.next().await {
                value.extend_from_slice(&chunk?);
            }
            body = String::from_utf8(value).unwrap();
        } else if field_name == "media" {
            if let Some(filename) = content_disposition.get_filename() {
                let sanitized_filename = sanitize(&filename);
                let filepath = format!("./uploads/article_{}", sanitized_filename);
                let mut f = File::create(&filepath)?;
                while let Some(chunk) = field.next().await {
                    f.write_all(&chunk?)?;
                }
                media_paths.push(format!("/uploads/article_{}", sanitized_filename));
            }
        }
    }

    if media_paths.is_empty() {
        return Ok(HttpResponse::BadRequest().body("Media file is required"));
    }

    let new_id = get_next_article_id(&db).unwrap_or(1);
    let key = format!("article_{}", new_id);
    let bump_time = Utc::now().timestamp();

    let article = Article {
        id: new_id,
        title,
        body,
        media_paths,
        bump_time,
    };

    if let Err(e) = db.insert(&key, serde_json::to_vec(&article).unwrap()) {
        log_error(&format!("Failed to store article: {}", e));
        return Ok(HttpResponse::InternalServerError().body(format!("Failed to store article: {}", e)));
    }

    Ok(HttpResponse::Found()
        .append_header(("Location", "/articles"))
        .finish())
}

// Helper function to get the next article ID from the database
fn get_next_article_id(db: &Db) -> sled::Result<u64> {
    let id_key = "current_article_id";
    let current_id = db
        .get(id_key)?
        .map(|v| u64::from_le_bytes(v.as_ref().try_into().unwrap()))
        .unwrap_or(0);
    let next_id = current_id + 1;
    db.insert(id_key, &next_id.to_le_bytes())?;
    Ok(next_id)
}

// Route to list all articles
async fn list_articles(db: web::Data<Arc<Db>>) -> HttpResponse {
    let mut articles: Vec<Article> = vec![];

    for entry in db.iter() {
        if let Ok((key, value)) = entry {
            if key.starts_with(b"article_") {
                if let Ok(article) = serde_json::from_slice::<Article>(&value) {
                    articles.push(article);
                }
            }
        }
    }

    // Sort by `bump_time` to ensure the most recently bumped article is at the top
    articles.sort_by(|a, b| b.bump_time.cmp(&a.bump_time));

    let mut articles_html = String::new();
    articles_html.push_str(&format!(r#"
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>{}</title>
        <link rel="stylesheet" href="/static/style.css">
    </head>
    <body>
        <h1>{}</h1>
        <div style="text-align: center; margin-bottom: 20px;">
            <a href="/">Submit a New Article</a>
        </div>
    "#, MAIN_PAGE_TITLE, MAIN_PAGE_TITLE));

    for article in &articles {
        articles_html.push_str(&format!(
            r#"<div class="article-link">
            <h2><a href="/articles/{}">{}</a></h2>
            </div>"#,
            article.id, article.title
        ));
    }

    articles_html.push_str("</body></html>");

    HttpResponse::Ok().content_type("text/html").body(articles_html)
}

// Route to view an article by ID
async fn view_article(db: web::Data<Arc<Db>>, path: web::Path<u64>) -> HttpResponse {
    let article_id = path.into_inner();
    let key = format!("article_{}", article_id);

    if let Ok(Some(value)) = db.get(&key) {
        if let Ok(article) = serde_json::from_slice::<Article>(&value) {
            let mut article_html = String::new();
            article_html.push_str(r#"
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>"#);
            article_html.push_str(&article.title);
            article_html.push_str("</title><link rel=\"stylesheet\" href=\"/static/style.css\"></head><body>");
            article_html.push_str(r#"<div style="text-align: center; margin-bottom: 20px;"><a href="/articles">← Back to All Articles</a></div>"#);
            article_html.push_str(&format!("<h1>{}</h1>", article.title));

            for media in &article.media_paths {
                if media.ends_with(".mp4") {
                    article_html.push_str(&format!(
                        r#"<video controls width="600">
                            <source src="{}" type="video/mp4">
                            Your browser does not support the video tag.
                        </video><br>"#,
                        media
                    ));
                } else {
                    article_html.push_str(&format!(r#"<img src="{}" alt="Article Image" style="max-width: 100%; height: auto;"><br>"#, media));
                }
            }

            article_html.push_str(&format!(r#"
            <p>{}</p>
            <h3>Leave a Comment</h3>
            <form action="/articles/{}/comment" method="POST">
                <textarea name="comment" rows="4" required></textarea><br>
                <input type="submit" value="Submit Comment">
            </form>
            <h3>Comments</h3>
            "#, article.body, article.id));

            let comments_key = format!("article_{}_comments", article.id);
            if let Ok(Some(comments_value)) = db.get(&comments_key) {
                let comments: Vec<String> = serde_json::from_slice(&comments_value).unwrap_or_default();
                for comment in comments {
                    article_html.push_str(&format!(r#"<div class="comment"><p>{}</p></div>"#, comment));
                }
            }

            article_html.push_str("</body></html>");
            return HttpResponse::Ok().content_type("text/html").body(article_html);
        }
    }

    HttpResponse::NotFound().body("Article not found")
}

// Route to handle comment submission
async fn submit_comment(db: web::Data<Arc<Db>>, path: web::Path<u64>, form: web::Form<CommentForm>) -> HttpResponse {
    let article_id = path.into_inner();
    let key = format!("article_{}_comments", article_id);

    let mut comments: Vec<String> = match db.get(&key) {
        Ok(Some(value)) => serde_json::from_slice(&value).unwrap_or_default(),
        _ => Vec::new(),
    };

    comments.push(form.comment.clone());

    if let Err(e) = db.insert(&key, serde_json::to_vec(&comments).unwrap()) {
        log_error(&format!("Failed to store comment: {}", e));
        return HttpResponse::InternalServerError().body(format!("Failed to store comment: {}", e));
    }

    // Bump the article to the top by updating the `bump_time`
    let article_key = format!("article_{}", article_id);
    if let Ok(Some(value)) = db.get(&article_key) {
        if let Ok(mut article) = serde_json::from_slice::<Article>(&value) {
            article.bump_time = Utc::now().timestamp();
            if let Err(e) = db.insert(&article_key, serde_json::to_vec(&article).unwrap()) {
                log_error(&format!("Failed to bump article: {}", e));
                return HttpResponse::InternalServerError().body(format!("Failed to bump article: {}", e));
            }
        }
    }

    HttpResponse::Found()
        .append_header(("Location", format!("/articles/{}", article_id)))
        .finish()
}
