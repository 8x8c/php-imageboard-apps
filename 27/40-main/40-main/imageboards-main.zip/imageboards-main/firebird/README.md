I am thinking of converting some of the apps from sqlite3 to Firebird Embedded db and other db's , it will not be for a while tho. 


![Screenshot 2024-12-02 102841](https://github.com/user-attachments/assets/ba1bea26-3afa-484b-81f5-c2e4c1cc063b)
