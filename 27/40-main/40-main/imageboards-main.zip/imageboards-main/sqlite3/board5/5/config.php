<?php
define('DB_PATH', 'forum.db');
define('MAX_MESSAGE_LENGTH', 1000);
?>

