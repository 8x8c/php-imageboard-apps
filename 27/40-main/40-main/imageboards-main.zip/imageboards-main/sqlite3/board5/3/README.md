# 3
one page php forum 

Sqlite3 db is created automatically when this script is ran the first time. A very simple yet powerful implementation of a php message board
with absurdly simple code. It makes you wonder why some php message boards have about 600 seperate php files.
