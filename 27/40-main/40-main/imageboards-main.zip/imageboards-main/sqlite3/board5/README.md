
# board 5 a bunch of simple boards

update--- all of this works on php 8.4.1 but it is coded for older versions so if anyone uses any of the apps, make sure to fully  update for  8.4.1 or the latest version. Just because old code works on the latest version of php, that does NOT mean your app is up to the latest version standards!! Some of this is really intersting and good tho 
