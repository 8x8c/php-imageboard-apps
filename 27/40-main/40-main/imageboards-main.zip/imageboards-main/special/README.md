
# /Special

This is for unique and special boards. Some do not even have a db! Others use unuque unconventional methods.
