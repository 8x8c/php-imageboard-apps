
Single file json imageboard. Made as a starter, you can easily ad features to it. Made to be easy, just run index.php and it makes the files /boards for you. Feed index.php to chatgpt or something and it can change anything you want! Tested on php 8.4.1 



![json1](https://github.com/user-attachments/assets/f7be77d5-8cb0-418f-b1f9-61531920ca78)


