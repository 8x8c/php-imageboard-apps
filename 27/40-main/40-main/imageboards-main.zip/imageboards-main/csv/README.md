this folder will have csv boards
