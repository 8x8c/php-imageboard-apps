bash stuff


postgre-rust.sh for rapid dev of rust apps using postgre -- nice way to tame postgres!! all u need is postgres installed, this does the rest. you need a db.sql with all ur tables tho. But this script is really cool- set up and run postgres apps without even going into postgres. 

postgre-php.sh manages making postgre db for php.  you need a db.sql with all ur tables tho.




maria.sh from zero to maria .db installed on your system.  bam. 

maria1.sh after maria is installed, fully automate db setup. 

all.bat say you want chatgpt to audit a multi file app. Well, run all.bat to put it all in one file instead of bothering to show chat gpt the files one by one!! 

xxcc.bat the ultimate way to rust dev on windows desktop 
